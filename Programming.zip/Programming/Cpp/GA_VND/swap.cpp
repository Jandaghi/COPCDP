
void del1node_yupdate(solotion &sol, int deli)
{
	//for(int j=1; j<=insol.size+1; j++)
	//	if(catg[insol.sol[j]]==catg[deli])
	//		insol.arrh[j]-=1;
	//	else 
	//		insol.arrh[j]=insol.arrh[j];
	//insol.arrh[insol.size]=0;
	//cpy_sol(sol0, sol);
	for(int j=deli; j<=sol.size+1; j++){
		sol.sol[j]=sol.sol[j+1];
	}
	
	sol.size--;
	
	h_calc(sol.arrh, sol.size, sol.sol);
		

	sol.tscor=scor_calc(sol.sol, sol.arrh, sol.size);
	sol.dist=dist_calc(sol.sol, sol.size);

}


void swap (solotion &sol, bool &swap_flg) 
{
	double min=99999;
	double diff=0;
	int selected_i=-1;
	int selected_k=-1;
	double rmain=dmax-sol.dist;

	swap_flg=false;

    for (int i=1; i<=sol.size-1; i++)
	{
	  for (int k=i+1; k<=sol.size; k++)
	  {
	     diff =distnc(sol.sol[i-1],sol.sol[k]) + distnc(sol.sol[i],sol.sol[k+1])
			- distnc(sol.sol[i-1],sol.sol[i]) - distnc(sol.sol[k],sol.sol[k+1]); 
			  
		 if (diff < min && diff < 0 && diff<-dmax)
		 {
			 selected_k = k;
			 selected_i = i;
			 min = diff;
			 swap_flg=true;
		  } 
	   }
    }
	if(swap_flg)
	{
		int slct=sol.sol[selected_i];
		sol.sol[selected_i]=sol.sol[selected_k];
		sol.sol[selected_k]=slct;

		int slcty=sol.arrh[selected_i];
		sol.arrh[selected_i]=sol.arrh[selected_k];
		sol.arrh[selected_k]=slcty;

		sol.dist=sol.dist+min; // chon min manfi ast
	}
}

void updt_scor_swap (solotion curr, int wht, int whr
	, double &out_scor)
{
	insert_in_sol(curr, curr, wht, whr);
	out_scor=scor_calc(curr.sol, curr.arrh, curr.size);




	//out_scor=0;
	//bool _flg=true;
	//int cs=0;

	//if(curr.size==0) out_scor = scor[wht];
	//for(int i=1; i<=curr.size; i++){
	//	if(catg[curr.sol[i]]==catg[wht]){
	//		curr.arrh[i]=curr.arrh[i]+1;
	//		
	//		if(_flg){
	//			cs=curr.arrh[i];
	//			_flg=false;
	//		}
	//	}else{
	//		curr.arrh[i]=curr.arrh[i];
	//	}
	//}
 //   curr.arrh[curr.size+1]=cs;
	//curr.arrh[curr.size+2]=0;
	////updt_y(curr, wht, whr, curr.arrh);	
	//
	//
	//for(int i=1; i<=curr.size; i++)
	//	//out_scor +=  scor[curr.sol[i]]/(curr.arrh[i]+1)*(1-alpha[catg[i]]);
	//out_scor += scor[curr.sol[i]]/((curr.arrh[i]+1)*(1-alpha[catg[curr.sol[i]]]));
}

void extract_insert (solotion &sol, bool &ext_flg)
{
	ext_flg=false;
	solotion sol0;
	cpy_sol(sol, sol0);
	solotion bst_sol;
	cpy_sol(sol, bst_sol);	
	double dif1, available_dist=dmax-sol.dist;
	int kk,temp_cust,temp_pos,day,temp_day,insert_score;
	double minn,diff,max,cheapest;
	int deletedi, deletediPos;
	bool feas=false;
	bool feas2=false;
	bool customers[maxn];
	int insertedj_pos[maxn];
	int insertedj_cust[maxn];
	int insertedjC[maxn];
	double changed_scor=0;

	for(int i=0; i<=n+1; i++)
		insertedj_pos[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedj_cust[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedjC[i]=0;
	for(int i=0; i<=n+1; i++)
		customers[i]=0;
	for(int i=1; i<=sol.size; i++)
		customers[sol.sol[i]]=1;
	double bst_tscor;
	
	int c=0;
	bool _fflg=false;
	bst_tscor=sol.tscor;
	for (int i=1; i<=sol.size; i++)
	{

		dif1=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif1;
		deletedi = sol.sol[i]; deletediPos = i;
		
		del1node_yupdate(sol, i);

		c=0;
		while(1)
		{
			max = -999 ;
			for (int k = 2; k<=n; k++)
			{
				if (customers[k]==0) 
				{
					minn=9999999;
					feas =false;
					for (int j=0; j<=sol.size;j++)
					{
						diff=distnc(sol.sol[j], k)+distnc(k, sol.sol[j+1])-distnc(sol.sol[j], sol.sol[j+1]);
						if (diff <= minn && diff <= available_dist && sol.sol[j]!=k)
						{
							minn=diff;
							kk=j+1;
							feas=true;
						}
					}
					double dlta_scor;
					if(feas){
						updt_scor_swap(sol, k, kk-1, changed_scor);
						dlta_scor=changed_scor-sol.tscor;
					}
															
					if (feas && dlta_scor>=0 && dlta_scor/minn > max)
					{
							temp_cust=k;
							temp_pos=kk;
							cheapest=minn;
							max=dlta_scor/minn;
							feas2=true;
					}
				}
			}
			
			if (max>0.00001 )
			{
				c++;
				insertedj_pos[c]=temp_pos;
				insertedj_cust[c]=temp_cust;
				insertedjC[c]=cheapest;
				insert_in_sol(sol, sol, temp_cust, temp_pos-1);
				_fflg=true;
				customers[temp_cust]=1;
				available_dist-=cheapest;
			}else{
				break;
			}
		}
		insert_score=0;
		int size = c;

		if (sol.tscor>bst_tscor){
			
			cpy_sol(sol, bst_sol);
			bst_tscor=sol.tscor;
			customers[deletedi] = 0;
			ext_flg=true;
			//cpy_sol(sol0, sol);

		}else{
			ext_flg=false;
			//cpy_sol(sol0, sol);
		}
	}
	cpy_sol(bst_sol, sol);
}

void extract_insert_2del (solotion &sol, bool &ext2_flg)
{
	ext2_flg=false;
	solotion sol0;
	cpy_sol(sol, sol0);
	solotion bst_sol;
	cpy_sol(sol, bst_sol);	
	double dif1, dif2, available_dist=dmax-sol.dist;
	int kk,temp_cust,temp_pos,day,temp_day,insert_score;
	double minn,diff,max,cheapest;
	int deletedi, deletediPos, deletedi2, deletediPos2;
	bool feas=false;
	bool customers[maxn];
	int insertedj_pos[maxn];
	int insertedj_cust[maxn];
	int insertedjC[maxn];
	double changed_scor=0;

	for(int i=0; i<=n+1; i++)
		insertedj_pos[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedj_cust[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedjC[i]=0;
	for(int i=0; i<=n+1; i++)
		customers[i]=0;
	for(int i=1; i<=sol.size; i++)
		customers[sol.sol[i]]=1;
	double bst_tscor;
	
	int c=0;
	bool _fflg=false;
	bst_tscor=sol.tscor;
	for (int i=1; i<=sol.size-1; i++)
	{

		dif1=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif1;
		deletedi = sol.sol[i]; deletediPos = i;
		

		del1node_yupdate(sol, i);

		dif2=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif2;
		deletedi2 = sol.sol[i]; deletediPos2 = i;

		del1node_yupdate(sol, i);

		c=0;
		while(1)
		{
			max = -999 ;
			for (int k = 2; k<=n; k++)
			{
				if (customers[k]==0) 
				{
					minn=9999999;
					feas =false;
					for (int j=0; j<=sol.size;j++)
					{
						diff=distnc(sol.sol[j], k)+distnc(k, sol.sol[j+1])-distnc(sol.sol[j], sol.sol[j+1]);
						if (diff <= minn && diff <= available_dist && sol.sol[j]!=k)
						{
							minn=diff;
							kk=j+1;
							feas=true;
						}
					}
					double dlta_scor;
					if(feas){
						updt_scor_swap(sol, k, kk-1, changed_scor);
						dlta_scor=changed_scor-sol.tscor;
					}
															
					if (feas && dlta_scor>=0 && dlta_scor/minn > max)
					{
							temp_cust=k;
							temp_pos=kk;
							cheapest=minn;
							max=dlta_scor/minn;
					}
				}
			}
			
			if (max>0.00001 )
			{
				c++;
				insertedj_pos[c]=temp_pos;
				insertedj_cust[c]=temp_cust;
				insertedjC[c]=cheapest;
				insert_in_sol(sol, sol, temp_cust, temp_pos-1);
				_fflg=true;
				customers[temp_cust]=1;
				available_dist-=cheapest;
			}else{
				break;
			}
		}
		insert_score=0;
		int size = c;

		if (sol.tscor>bst_tscor){
			
			cpy_sol(sol, bst_sol);
			bst_tscor=sol.tscor;
			customers[deletedi] = 0;
			ext2_flg=true;
			//cpy_sol(sol0, sol);

		}else{
			ext2_flg=false;
			//cpy_sol(sol0, sol);
		}
	}
	cpy_sol(bst_sol, sol);
}


void extract_insert_3del (solotion &sol, bool &ext3_flg)
{
	ext3_flg=false;
	solotion sol0;
	cpy_sol(sol, sol0);
	solotion bst_sol;
	cpy_sol(sol, bst_sol);	
	double dif1, dif2, dif3, available_dist=dmax-sol.dist;
	int kk,temp_cust,temp_pos,day,temp_day,insert_score;
	double minn,diff,max,cheapest;
	int deletedi, deletediPos, deletedi2, deletediPos2, deletedi3, deletediPos3;
	bool feas=false;
	bool customers[maxn];
	int insertedj_pos[maxn];
	int insertedj_cust[maxn];
	int insertedjC[maxn];
	double changed_scor=0;

	for(int i=0; i<=n+1; i++)
		insertedj_pos[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedj_cust[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedjC[i]=0;
	for(int i=0; i<=n+1; i++)
		customers[i]=0;
	for(int i=1; i<=sol.size; i++)
		customers[sol.sol[i]]=1;
	double bst_tscor;
	
	int c=0;
	bool _fflg=false;
	bst_tscor=sol.tscor;
	for (int i=1; i<=sol.size-2; i++)
	{

		dif1=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif1;
		deletedi = sol.sol[i]; deletediPos = i;
		

		del1node_yupdate(sol, i);

		dif2=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif2;
		deletedi2 = sol.sol[i]; deletediPos2 = i;

		del1node_yupdate(sol, i);

		dif3=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif3;
		deletedi3 = sol.sol[i]; deletediPos3 = i;

		del1node_yupdate(sol, i);

		c=0;
		while(1)
		{
			max = -999 ;
			for (int k = 2; k<=n; k++)
			{
				if (customers[k]==0) 
				{
					minn=9999999;
					feas =false;
					for (int j=0; j<=sol.size;j++)
					{
						diff=distnc(sol.sol[j], k)+distnc(k, sol.sol[j+1])-distnc(sol.sol[j], sol.sol[j+1]);
						if (diff <= minn && diff <= available_dist && sol.sol[j]!=k)
						{
							minn=diff;
							kk=j+1;
							feas=true;
						}
					}
					double dlta_scor;
					if(feas){
						updt_scor_swap(sol, k, kk-1, changed_scor);
						dlta_scor=changed_scor-sol.tscor;
					}
															
					if (feas && dlta_scor>=0 && dlta_scor/minn > max)
					{
							temp_cust=k;
							temp_pos=kk;
							cheapest=minn;
							max=dlta_scor/minn;
					}
				}
			}
			
			if (max>0.00001 )
			{
				c++;
				insertedj_pos[c]=temp_pos;
				insertedj_cust[c]=temp_cust;
				insertedjC[c]=cheapest;
				insert_in_sol(sol, sol, temp_cust, temp_pos-1);
				_fflg=true;
				customers[temp_cust]=1;
				available_dist-=cheapest;
			}else{
				break;
			}
		}
		insert_score=0;
		int size = c;

		if (sol.tscor>bst_tscor){
			
			cpy_sol(sol, bst_sol);
			bst_tscor=sol.tscor;
			customers[deletedi] = 0;
			ext3_flg=true;
			//cpy_sol(sol0, sol);

		}else{
			ext3_flg=false;
			//cpy_sol(sol0, sol);
		}
	}
	cpy_sol(bst_sol, sol);
}


void extract_insert_4del (solotion &sol, bool &ext4_flg)
{
	ext4_flg=false;
	solotion sol0;
	cpy_sol(sol, sol0);
	solotion bst_sol;
	cpy_sol(sol, bst_sol);	
	double dif1, dif2, dif3, dif4, available_dist=dmax-sol.dist;
	int kk,temp_cust,temp_pos,day,temp_day,insert_score;
	double minn,diff,max,cheapest;
	int deletedi, deletediPos, deletedi2, deletediPos2, deletedi3, deletediPos3, deletedi4, deletediPos4;
	bool feas=false;
	bool customers[maxn];
	int insertedj_pos[maxn];
	int insertedj_cust[maxn];
	int insertedjC[maxn];
	double changed_scor=0;

	for(int i=0; i<=n+1; i++)
		insertedj_pos[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedj_cust[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedjC[i]=0;
	for(int i=0; i<=n+1; i++)
		customers[i]=0;
	for(int i=1; i<=sol.size; i++)
		customers[sol.sol[i]]=1;
	double bst_tscor;
	
	int c=0;
	bool _fflg=false;
	bst_tscor=sol.tscor;
	for (int i=1; i<=sol.size-3; i++)
	{

		dif1=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif1;
		deletedi = sol.sol[i]; deletediPos = i;
	
		del1node_yupdate(sol, i);

		dif2=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif2;
		deletedi2 = sol.sol[i]; deletediPos2 = i;

		del1node_yupdate(sol, i);

		dif3=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif3;
		deletedi3 = sol.sol[i]; deletediPos3 = i;

		del1node_yupdate(sol, i);

		dif4=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif4;
		deletedi4 = sol.sol[i]; deletediPos4 = i;

		del1node_yupdate(sol, i);

		c=0;
		while(1)
		{
			max = -999 ;
			for (int k = 2; k<=n; k++)
			{
				if (customers[k]==0) 
				{
					minn=9999999;
					feas =false;
					for (int j=0; j<=sol.size;j++)
					{
						diff=distnc(sol.sol[j], k)+distnc(k, sol.sol[j+1])-distnc(sol.sol[j], sol.sol[j+1]);
						if (diff <= minn && diff <= available_dist && sol.sol[j]!=k)
						{
							minn=diff;
							kk=j+1;
							feas=true;
						}
					}
					double dlta_scor;
					if(feas){
						updt_scor_swap(sol, k, kk-1, changed_scor);
						dlta_scor=changed_scor-sol.tscor;
					}
															
					if (feas && dlta_scor>=0 && dlta_scor/minn > max)
					{
							temp_cust=k;
							temp_pos=kk;
							cheapest=minn;
							max=dlta_scor/minn;
					}
				}
			}
			
			if (max>0.00001)
			{
				c++;
				insertedj_pos[c]=temp_pos;
				insertedj_cust[c]=temp_cust;
				insertedjC[c]=cheapest;
				insert_in_sol(sol, sol, temp_cust, temp_pos-1);
				_fflg=true;
				customers[temp_cust]=1;
				available_dist-=cheapest;
			}else{
				break;
			}
		}
		insert_score=0;
		int size = c;

		if (sol.tscor>bst_tscor){
			
			cpy_sol(sol, bst_sol);
			bst_tscor=sol.tscor;
			customers[deletedi] = 0;
			ext4_flg=true;
			//cpy_sol(sol0, sol);

		}else{
			ext4_flg=false;
			//cpy_sol(sol0, sol);
		}
	}
	cpy_sol(bst_sol, sol);
}

void extract_insert_5del (solotion &sol, bool &ext5_flg)
{
	ext5_flg=false;
	solotion sol0;
	cpy_sol(sol, sol0);
	solotion bst_sol;
	cpy_sol(sol, bst_sol);	
	double dif1, dif2, dif3, dif4, dif5, available_dist=dmax-sol.dist;
	int kk,temp_cust,temp_pos,day,temp_day,insert_score;
	double minn,diff,max,cheapest;
	int deletedi, deletediPos, deletedi2, deletediPos2, deletedi3, deletediPos3, deletedi4, deletediPos4, deletedi5, deletediPos5;
	bool feas=false;
	bool customers[maxn];
	int insertedj_pos[maxn];
	int insertedj_cust[maxn];
	int insertedjC[maxn];
	double changed_scor=0;

	for(int i=0; i<=n+1; i++)
		insertedj_pos[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedj_cust[i]=0;
	for(int i=0; i<=n+1; i++)
		insertedjC[i]=0;
	for(int i=0; i<=n+1; i++)
		customers[i]=0;
	for(int i=1; i<=sol.size; i++)
		customers[sol.sol[i]]=1;
	double bst_tscor;
	
	int c=0;
	bool _fflg=false;
	bst_tscor=sol.tscor;
	for (int i=1; i<=sol.size-4; i++)
	{

		dif1=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif1;
		deletedi = sol.sol[i]; deletediPos = i;
	
		del1node_yupdate(sol, i);

		dif2=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif2;
		deletedi2 = sol.sol[i]; deletediPos2 = i;

		del1node_yupdate(sol, i);

		dif3=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif3;
		deletedi3 = sol.sol[i]; deletediPos3 = i;

		del1node_yupdate(sol, i);

		dif4=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif4;
		deletedi4 = sol.sol[i]; deletediPos4 = i;

		del1node_yupdate(sol, i);

		dif5=distnc(sol.sol[i-1], sol.sol[i+1])-distnc(sol.sol[i-1], sol.sol[i])-distnc(sol.sol[i], sol.sol[i+1]);
		available_dist-=dif5;
		deletedi5 = sol.sol[i]; deletediPos5 = i;

		del1node_yupdate(sol, i);
		c=0;
		while(1)
		{
			max = -999 ;
			for (int k = 2; k<=n; k++)
			{
				if (customers[k]==0) 
				{
					minn=9999999;
					feas =false;
					for (int j=0; j<=sol.size;j++)
					{
						diff=distnc(sol.sol[j], k)+distnc(k, sol.sol[j+1])-distnc(sol.sol[j], sol.sol[j+1]);
						if (diff <= minn && diff <= available_dist && sol.sol[j]!=k)
						{
							minn=diff;
							kk=j+1;
							feas=true;
						}
					}
					double dlta_scor;
					if(feas){
						updt_scor_swap(sol, k, kk-1, changed_scor);
						dlta_scor=changed_scor-sol.tscor;
					}
															
					if (feas && dlta_scor>=0 && dlta_scor/minn > max)
					{
							temp_cust=k;
							temp_pos=kk;
							cheapest=minn;
							max=dlta_scor/minn;
					}
				}
			}
			
			if (max>0.00001)
			{
				c++;
				insertedj_pos[c]=temp_pos;
				insertedj_cust[c]=temp_cust;
				insertedjC[c]=cheapest;
				insert_in_sol(sol, sol, temp_cust, temp_pos-1);
				_fflg=true;
				customers[temp_cust]=1;
				available_dist-=cheapest;
			}else{
				break;
			}
		}
		insert_score=0;
		int size = c;

		if (sol.tscor>bst_tscor){
			
			cpy_sol(sol, bst_sol);
			bst_tscor=sol.tscor;
			customers[deletedi] = 0;
			ext5_flg=true;
			//cpy_sol(sol0, sol);

		}else{
			ext5_flg=false;
			//cpy_sol(sol0, sol);
		}
	}
	cpy_sol(bst_sol, sol);
}

//
//void extract_insert2 (solotion &sol, bool &ext_flg)
//{
//	ext_flg=false;
//	solotion sol0;
//	cpy_sol(sol, sol0);
//	double dif1, available_dist=sol.dist;
//	int zz,kk,temp_cust,temp_pos,day,temp_day,insert_score;
//	double minn,diff,max,cheapest;
//	int deletedi, deletediPos;
//	bool feas,indicator=false;
//	bool selected[maxn];
//	int insertedj_pos[maxn];
//	int insertedj_cust[maxn];
//	int insertedjC[maxn];
//	double changed_scor=-9999;
//
//	for(int i=0; i<=n+1; i++)
//		insertedj_pos[i]=0;
//	for(int i=0; i<=n+1; i++)
//		insertedj_cust[i]=0;
//	for(int i=0; i<=n+1; i++)
//		insertedjC[i]=0;
//	for(int i=0; i<=n+1; i++)
//		selected[i]=0;
//	for(int i=0; i<=sol.size+1; i++)
//		selected[sol.sol[i]]=1;
//	int c=0;
//
//	for(int i=1; i<=sol.size-1; i++)
//	{
//		for(int j=i+1; j<=sol.size; j++)
//		{
//			diff=distnc(sol.sol[i-1], sol.sol[i+1])-
//			distnc(sol.sol[i-1], sol.sol[i])-
//			distnc(sol.sol[i], sol.sol[i+1])
//
//			+distnc(sol.sol[j-1], sol.sol[j+1])-
//			distnc(sol.sol[j-1], sol.sol[j])-
//			distnc(sol.sol[j], sol.sol[j+1]);
//			for(int k=1; k<=n; k++)
//			{
//				if (selected[k]==0) 
//				{
//					dif1=0;
//				}
//			}
//
//		}
//	}
//}

//void extract_insert2_dr (vector<vector<int>>&solution){
//	double dif1;
//	int zz,kk,temp_cust,temp_pos,day,temp_day,insert_score;
//	double minn,diff,max,cheapest;
//	int deletedi, deletediPos,deletedi2;
//	bool feas,indicator=false;
//	
//	for (int d=0; d<m; d++){
//		for (int i=1; i<solution[d].size()-2; i++){
//			//vector<vector<int>> insertedj;vector<double> insertedjC;
//			insertedj.clear();insertedjC.clear();
//			insertedj.resize(2);
//			
//
//			dif1=cost[solution[d][i-1]][solution[d][i+2]]-cost[solution[d][i-1]][solution[d][i]]-cost[solution[d][i]][solution[d][i+1]]-cost[solution[d][i+1]][solution[d][i+2]];
//			available_cost[d]-=dif1;
//			deletedi = solution[d][i];deletedi2=solution[d][i+1]; deletediPos = i;
//			solution[d].erase(solution[d].begin()+i);
//			solution[d].erase(solution[d].begin()+i);
//			while(1)
//			{
//				max = -999 ;
//				for (int k = h+2; k<n+h; k++)
//				{
//					if (customers[k]!=-1) 
//					{
//						minn=9999999;
//						feas =false;
//						for (int j=0; j<solution[d].size()-1;j++){
//							zz=j+1;
//							diff=cost[solution[d][j]][customers[k]]+cost[customers[k]][solution[d][zz]]-cost[solution[d][j]][solution[d][zz]];
//							if (diff <= minn){
//								if ( diff <= available_cost[d]){
//									minn=diff;
//									kk=j+1;
//									day=d;
//									feas=true;
//								}
//							}
//						}
//
//						if (feas)
//						{
//							if (score[customers[k]]/minn > max){
//								temp_cust=customers[k];
//								temp_pos=kk;
//								temp_day=day;
//								cheapest=minn;
//								max=score[customers[k]]/minn;
//							}
//						}
//					}
//				}
//				if (max>0.00001){
//					insertedj[0].push_back(temp_cust);
//					insertedj[1].push_back(temp_pos);
//					insertedjC.push_back(cheapest);
//					solution[temp_day].insert (solution[temp_day].begin()+temp_pos,temp_cust);
//					/*indicator=true;*/
//					customers[temp_cust]=-1;
//					available_cost[temp_day]-=cheapest;
//				}else{
//					break;
//				}
//			}
//			insert_score=0;
//			int size = insertedj[0].size();
// 			for (int v=0; v<size ; v++) 
//				insert_score+=score[insertedj[0][v]];
//
//			if (score[deletedi]+score[deletedi2]>=insert_score){
//				for (int ss = size-1; ss>=0; ss--)
//				{
//					solution[d].erase(solution[d].begin()+insertedj[1][ss]);
//					available_cost[d]+= insertedjC[ss];
//				}
//				solution[d].insert(solution[d].begin()+deletediPos,deletedi);
//				solution[d].insert(solution[d].begin()+deletediPos+1,deletedi2);
//				available_cost[d]+= dif1;
//				for (int ss = size-1; ss>=0; ss--)
//				{
//					customers[insertedj[0][ss]] = insertedj[0][ss];
//				}
//			}else {
//				indicator = true;
//				customers[deletedi] = deletedi;
//				customers[deletedi2] = deletedi2;
//			}
//		}
//	}
//	if (!indicator){ level++;/*no_imp++;*/}
//	else {level=1; /*no_imp=0;*/}
//}


