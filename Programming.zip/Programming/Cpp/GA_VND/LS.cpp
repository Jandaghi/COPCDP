
void local_search (solotion sol2, solotion &sol3)
{
	bool insrt_flg=true;
	bool opt_flg=true;
	bool swap_flg=true;
	bool ext_flg=true;
	bool ext2_flg=true;
	bool ext3_flg=true;
	bool ext4_flg=true;
	bool ext5_flg=true;

	again:
	while(insrt_flg)
	{
		best_insert_BestImp (sol2, sol3, insrt_flg);
		if(insrt_flg)
		   cpy_sol(sol3, sol2);
	}

	two_opt_BestImprove(sol2, opt_flg);    
	if(opt_flg)
	{
		insrt_flg=true;
		goto again;		
	}
    extract_insert(sol2, ext_flg);
	if(ext_flg)
	{
		insrt_flg=true;
		goto again;
	}
    extract_insert_2del(sol2, ext2_flg);
	if(ext2_flg)
	{
		insrt_flg=true;
		goto again;	
	}

	cpy_sol(sol2, sol3);
}


