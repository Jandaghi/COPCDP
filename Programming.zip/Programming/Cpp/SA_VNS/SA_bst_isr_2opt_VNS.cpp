#include "initial_NN.cpp"
#include "bst_insrt.cpp"
#include "two_opt.cpp"
#include "swap.cpp"

void local_search (solotion sol2, solotion &sol3)
{
	bool insrt_flg=true;
	bool opt_flg=true;
	bool swap_flg=true;
	bool ext_flg=true;
	bool ext2_flg=true;
	bool ext3_flg=true;
	bool ext4_flg=true;
	bool ext5_flg=true;

	again:
	while(insrt_flg)
	{
		best_insert_BestImp (sol2, sol3, insrt_flg);
		if(insrt_flg)
		   cpy_sol(sol3, sol2);
	}
	//swap(sol2, swap_flg);
	//if(swap_flg)
	//{
	//	insrt_flg=true;
	//	goto again;
	//}
	two_opt_BestImprove(sol2, opt_flg);
	if(opt_flg)
	{
		insrt_flg=true;
		goto again;
	}
    extract_insert(sol2, ext_flg);
	if(ext_flg)
	{
		insrt_flg=true;
		goto again;
		//swap_flg=true;
		//goto here;
	}
    extract_insert_2del(sol2, ext2_flg);
	if(ext2_flg)
	{
		insrt_flg=true;
		goto again;	
		//swap_flg=true;
		//goto here;
	}

 //   extract_insert_3del(sol2, ext3_flg);
	//if(ext3_flg)
	//{
	//	insrt_flg=true;
	//	goto again;
	//	//swap_flg=true;
	//	//goto here;
	//}

 //   extract_insert_4del(sol2, ext4_flg);
	//if(ext4_flg)
	//{
	//	insrt_flg=true;
	//	goto again;
	//	//swap_flg=true;
	//	//goto here;
	//}
 //   extract_insert_5del(sol2, ext5_flg);
	//if(ext5_flg)
	//{
	//	insrt_flg=true;
	//	goto again;
	//	//swap_flg=true;
	//	//goto here;
	//}

	cpy_sol(sol2, sol3);
}

void shaking (solotion cur, solotion &cur2, double beta) 
{
	int dlt=0;
	int rnd_num;
	dlt=beta*cur.size;
	int slct_rnd[maxn];


	for(int i=1; i<=dlt; i++)
	{
		//here:
		rnd_num=1 + int((cur.size)*rand()/(RAND_MAX + 1.0));
		//if(slct_rnd[rnd_num]==-1) 
			//goto here;
		//slct_rnd[rnd_num]=-1;

		//cur.dist=cur.dist-distnc(cur.sol[rnd_num-1],cur.sol[rnd_num])-distnc(cur.sol[rnd_num],cur.sol[rnd_num+1]);
		//cur.dist=cur.dist+distnc(cur.sol[rnd_num-1],cur.sol[rnd_num+1]);
		//cur.tscor-= scor[cur.sol[rnd_num]]/(1-alpha[catg[cur.sol[rnd_num]]])*(1+cur.arrh[rnd_num]);
		
		for(int j=rnd_num; j<=cur.size; j++)
		{
			cur.sol[j]=cur.sol[j+1];
			if(catg[cur.sol[j]]==catg[cur.sol[rnd_num]])
			{
				cur.arrh[j]=cur.arrh[j+1]-1;
				//cur.tscor-= scor[cur.sol[j]]/(1-alpha[catg[cur.sol[j]]])*(1+cur.arrh[j]);
				//cur.tscor-= pow(alpha[catg[cur.sol[j]]],  cur.arrh[j]) * scor[cur.sol[j]];
				//cur.tscor-= scor[cur.sol[j]]/(1-alpha[catg[cur.sol[j]]])*(1+cur.arrh[rnd_num]-1);
				//cur.tscor+= pow(alpha[catg[cur.sol[j]]],  cur.arrh[j]-1) * scor[cur.sol[j]];
			}
			if(catg[cur.sol[j]]!=catg[cur.sol[rnd_num]])
				cur.arrh[j]=cur.arrh[j+1];
		}
		cur.size--;
	}
	//for (int i=cur.size+2; i<=cur.size+dlt+1; i++)
	//	cur.sol[i] = -1;
	
	h_calc(cur.arrh, cur.size, cur.sol);
	cur.dist = dist_calc(cur.sol,cur.size);
	cur.tscor = scor_calc(cur.sol, cur.arrh, cur.size);
	cpy_sol(cur,cur2);
}

//void local_search0 (solotion sol2,solotion &sol3)
//{
//	bool imp_flg=true;
//
//	two_opt_BestImprove(sol2, imp_flg);
//	
//	while(imp_flg)
//	{
//		//bst_insrt(curr,imp,imp_flg);
//		bst_insrt (sol2,sol3,imp_flg);
//		
//		if(imp_flg)
//			cpy_sol(sol3,sol2);
//	}
//	//two_opt_FirstImprove(sol3);
//	int gf=0;
//}




void shaking0 (solotion cur, solotion &cur2, double beta) 
{
	int dlt=0;
	int rnd_num;
	dlt=beta*cur.size;
	int slct_rnd[maxn];

	for(int i=1; i<=dlt; i++)
	{
		here:
		rnd_num=1 + int((cur.size)*rand()/(RAND_MAX + 1.0));
		if(slct_rnd[rnd_num]==-1) goto here;
		slct_rnd[rnd_num]=-1;
		cur.dist=cur.dist-distnc(cur.sol[rnd_num-1],cur.sol[rnd_num])-distnc(cur.sol[rnd_num],cur.sol[rnd_num+1]);
		cur.dist=cur.dist+distnc(cur.sol[rnd_num-1],cur.sol[rnd_num+1]);
		cur.tscor-= pow(alpha[catg[cur.sol[rnd_num]]],  cur.arrh[rnd_num]-1) * scor[cur.sol[rnd_num]];
		for(int j=rnd_num; j<=cur.size; j++)
		{
			cur.sol[j]=cur.sol[j+1];
			if(catg[cur.sol[j]]==catg[cur.sol[rnd_num]])
			{
				cur.arrh[j]=cur.arrh[j+1]-1;
				cur.tscor-= pow(alpha[catg[cur.sol[j]]],  cur.arrh[j]) * scor[cur.sol[j]];
				cur.tscor+= pow(alpha[catg[cur.sol[j]]],  cur.arrh[j]-1) * scor[cur.sol[j]];
			}
			if(catg[cur.sol[j]]!=catg[cur.sol[rnd_num]])
				cur.arrh[j]=cur.arrh[j+1];
		}
		cur.size--;
	}
	cpy_sol(cur,cur2);
}

void SA_imp0 (solotion init, solotion &imp)
{
	double T=100;
	const double Tmin=0.5;
	const double alpa=0.9;
	int iter_max=50;
	double rnd;
	int iter;
	bool SA_condition=false;
	double delta;
	double delta2;
	solotion curr;
	solotion curr2;
	solotion curr3;
	solotion bst;
	cpy_sol(init,curr);
	cpy_sol(init,bst);
	cpy_sol(init,curr2);
	cpy_sol(init,curr3);
	//cpy_sol(init,curr2);

	strt=clock();
	
    while(T>=Tmin) 
	{ 
		iter=1;                               //curr=s  //curr2=s'  //curr3=s"
		while(iter<=iter_max)
		{   
			
			local_search(curr2,curr3);
			
			delta=curr3.tscor-curr2.tscor;
			delta2=curr.tscor-bst.tscor;
			if(delta>0) {
				
				cpy_sol(curr3,curr);
			
			}

			if(delta2>0) {
				cpy_sol(curr,bst);			
			}
     		rnd=(double) rand() / (RAND_MAX + 1);
			if  (delta>0 && exp(((-1)*delta)/T)>rnd){
				cpy_sol(curr3,curr);  
			}
			
			iter++;
			shaking(curr,curr2,0.6);
            
		}
			
		T=alpa*T;
		
	}
	cpy_sol(bst,imp);
	if(imp.tscor==0) 
		cpy_sol(init,imp);
	stp=clock();
}

void SA_set_par(int par_set_name, double &T, int &iter_max, int &improveMax, float &alpa, float &beta)
{	
	T=SA_T[par_set_name];
	iter_max=SA_itr[par_set_name];
	improveMax=SA_itr[par_set_name];
	alpa=SA_alpa[par_set_name];
	beta=SA_beta[par_set_name];
}

void SA_imp (solotion init, solotion &imp, bool mode)
{
	if(mode)
		goto Taguchi;
	//SA Parameters..............................................................

	double       T= 10;
	float        alpa= 0.95;
	float        beta= 0.6;
	int          iter_max= 5;
	int          improveMax= 5;	
	//...........................................................................

	if(mode)
	{
		Taguchi:
		
		SA_set_par(give_par_set_name, T, iter_max, improveMax, alpa, beta);
	}

	double rnd;
	float        Tmin= 1;
	int iter;
	bool SA_condition=false;
	double delta;
	double delta2;	
	solotion sol1;
	solotion sol2;
	solotion sol3;
	solotion bst;
	cpy_sol(init,sol1);
	cpy_sol(init,sol2);
	cpy_sol(init,sol3);
	cpy_sol(init,bst);
	
	
	int improveCount = 0;

    while(T>=Tmin) 
	{ 
		iter=1;
		improveCount=0;
		while(/*iter<=iter_max && */improveCount <= improveMax )
		{   
			local_search(sol2,sol3);
			delta=sol3.tscor-bst.tscor;
			delta2=sol3.tscor-sol1.tscor;
			if(delta>=0) {
				cpy_sol(sol3,bst);			
			}else{
				improveCount++;
			}
			if(delta2>=0) { 
				cpy_sol(sol3,sol1);							
			}else{
				rnd=(double) rand() / (RAND_MAX + 1);
				if  (exp(((-1)*delta)/T)>rnd)
					cpy_sol(sol3,sol1);
			}
			shaking(sol1,sol2,beta);
			iter++;
		}
		T=alpa*T;	
	}

	cpy_sol(bst,imp);
 
	stp=clock();		
}



void main()
{
	solotion init1;
	solotion init2;
	
	solotion imp1;
	solotion imp2;

	srand((unsigned)time(0));

	bool mode=0;
	//cout<<"Select mode: 0 Normal    1 Taguchi (0 or 1)?  ";
	//cin>> mode;
	if(!mode)
		goto normal;
	else
		goto Taguchi;

	normal:
	NextInstance:

	input ();

	strt=clock();

	initial_sol1 (init1);
	//initial_sol_y (init2);

	//if(init1.tscor>=init2.tscor)
	//{
		output (init1, 0);
		SA_imp (init1, imp1, 0);
		output (imp1, 1);
	//}else{
	//	output (init2, 0);
	//	SA_imp (init2, imp2, 0);
	//	output (imp2, 1);
	// }
	
	goto NextInstance;

	if(mode)
	{
		Taguchi:
		cout<<"Give SA parameter set name? (1 to 25) ";
		cin>>give_par_set_name;
		double tagu_scor[6][16];
		double tagu_time[6][16];
		for(int i=0; i<=16;i++)
			for(int j=0; j<=5; j++)
				tagu_scor[j][i]=0;
		for(int i=0; i<=16;i++)
			for(int j=0; j<=5; j++)
				tagu_time[j][i]=0;
		int ins=1;
		for(int i=1; i<=15; ins=foo(i))
		{
			input_Taguchi(ins);
			initial_sol1 (init1);
			initial_sol_y (init2);
			for(int j=1; j<=5; j++)
			{
				if(init1.tscor>=init2.tscor){
					SA_imp (init1, imp1, 1);
					tagu_scor[j][i]=imp1.tscor;
					tagu_time[j][i]=(stp-strt)/double(CLOCKS_PER_SEC) ;
				}else{
					SA_imp (init2, imp2, 1);
					tagu_scor[j][i]=imp2.tscor;
					tagu_time[j][i]=(stp-strt)/double(CLOCKS_PER_SEC) ;
				}				
			}
			cout<< "Instance("<<i<<") done!"<<endl;
			cout<< 6.6666666666666666666666666666667*i<<" % of total proccess is done"<<endl;
			i++;
		}
		ofstream outfile;
		outfile.open("Result_Tscore.txt", ios::out);
	
		//outfile <<sol.tscor<<"\t";
		ins=1;
		for(int i=1; i<=15; ins=foo(i))
		{
			//outfile << ins<< "\t";
			for(int j=1; j<=5; j++)
				outfile <<tagu_scor[j][i]<<"\t";
			outfile<<"\n";
			i++;
		}
		outfile.close();
		ofstream outfile1;
		outfile1.open("Result_Time.txt", ios::out);
	
		//outfile <<sol.tscor<<"\t";
		ins=1;
		for(int i=1; i<=15; ins=foo(i))
		{
			//outfile << ins<< "\t";
			for(int j=1; j<=5; j++)
				outfile1 <<tagu_time[j][i]<<"\t";
			outfile1<<"\n";
			i++;
		}
		outfile1.close();
	}
	//system("pause");
}












 //   std::cout << std::fixed;
 //   std::cout << std::setprecision(2);
	//for(int i=0; i<=10;i++) cout<<i<<"     ";
	//for(int i=0; i<=10;i++){
	//	cout<<endl;
	//	for(int j=0; j<=10;j++)
	//		cout<< distnc(i,j)<<"  ";}
	// cout<<endl;                                      // show distance matrix
	//system("pause");

	

    //cout<<endl<<scor_calc(imp.sol,imp.arrh,imp.size)<<endl;
	//system("pause");