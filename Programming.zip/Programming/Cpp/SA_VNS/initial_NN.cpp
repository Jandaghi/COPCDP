///////////////////////////////////////////////// Definition ////////////////////////////////////////////////////
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <time.h>
#include <vector>
#include <iomanip>
#include <ctime>
#include <windows.h>

using namespace std;
#define maxn 2001
#define maxc 21

int n, dmax, n_cat;
double myx[maxn], myy[maxn], scor[maxn], alpha[maxc];
int catg[maxn];
double strt;
double stp;
int itr=5;
double SA_T[26];double SA_alpa[26];double SA_beta[26];
int SA_itr[26];

int foo(int i){
	int tagu_instanc[16]={0,1,2,4,6,8,9,11,12,21,22,23,24,28,30,31};
	return tagu_instanc[i];
}
int give_par_set_name=1; //from 1 to 25
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void SetColor(int value){
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),  value);
}

struct solotion
{
	int sol[maxn];
	int arrh[maxn];
	double dist;
	double tscor;
	int size;
};

void input_Taguchi (int inst_name) 
{
	int i; char filename[200]; FILE *fp;

	sprintf(filename, "%d", inst_name);
	strcat (filename, ".txt");
	fp = fopen (filename,"r");
	fscanf (fp, "%d %d %d", &n, &dmax, &n_cat);
	for (i = 1; i <= n_cat; i++) fscanf (fp, "%lf", alpha+i);
	if (n > maxn) {printf ("Too many objects\n\n"); return;} 
	for (i = 0; i <= n; i++) fscanf (fp, "%lf %lf %lf %d", myx+i, myy+i, scor+i, catg+i);
	double x1,y1,s1; x1=myx[1];y1=myy[1];s1=scor[1];
	for (i = 1; i <= n-2; i++) {myx[i]=myx[i+1];myy[i]=myy[i+1];scor[i]=scor[i+1];catg[i]=catg[i+1];}
	myx[n-1]=x1; myy[n-1]=y1; scor[n-1]=s1; catg[n-1]=0;n--;n--;
	fclose (fp);
	

	char *file_taguchi;
	//file_taguchi="taguchi";
	fp = fopen ("taguchi.txt","r");
	//strcat (file_taguchi, ".txt");
	for(int i=1; i<=25; i++) fscanf (fp, "%lf %lf %lf %d", SA_T+i, SA_alpa+i, SA_beta+i, SA_itr+i);
	fclose (fp);

	return; 
}

void input () 
{
	int i; char filename[20]; FILE *fp;
	printf ("Give the instance file name: "); 
	scanf ("%s", filename); strcat (filename, ".txt");
	fp = fopen (filename,"r");
	fscanf (fp, "%d %d %d", &n, &dmax, &n_cat);
	for (i = 1; i <= n_cat; i++) fscanf (fp, "%lf", alpha+i);
	if (n > maxn) {printf ("Too many objects\n\n"); return;} 
	for (i = 0; i <= n; i++) fscanf (fp, "%lf %lf %lf %d", myx+i, myy+i, scor+i, catg+i);
	double x1,y1,s1; x1=myx[1];y1=myy[1];s1=scor[1];
	for (i = 1; i <= n-2; i++) {myx[i]=myx[i+1];myy[i]=myy[i+1];scor[i]=scor[i+1];catg[i]=catg[i+1];}
	myx[n-1]=x1; myy[n-1]=y1; scor[n-1]=s1; catg[n-1]=0;n--;n--;
	fclose (fp);return; 
}

double distnc (int fr, int to)
{
	return sqrt((myx[fr]-myx[to])*(myx[fr]-myx[to])+(myy[fr]-myy[to])*(myy[fr]-myy[to]));
}

double dist_calc(int sol[maxn], int size){
	double summ=0;
	for(int i=0;i<size;i++)
		summ+=distnc(sol[i],sol[i+1]);
	summ+=distnc(sol[size],n+1);
	return summ;
}

void cpy_sol(solotion from , solotion &to)
{
	for(int i=0; i<=from.size+1; i++)
		to.sol[i]=from.sol[i];
	for(int i=0; i<=from.size+1; i++)
		to.arrh[i]=from.arrh[i];
	to.tscor=from.tscor;
	to.dist=from.dist;
	to.size=from.size;
}

void h_calc(int (&arr_h)[maxn], int sol_size, int sol[maxn])
{
	int cntr[maxn/2+1]; //counter of h visited in each category

    for(int i=0; i<=n; i++)
        cntr[i]=0;

    for(int i=1; i<=sol_size; i++)
        cntr[catg[sol[i]]]++;

    for(int i=1; i<=sol_size; i++)
        arr_h [i] = cntr[catg[sol[i]]];	
}

double scor_calc( int sol[maxn], int arr_h[maxn], int sol_size )
{
	double tscr=0;
	for(int i=1; i<=sol_size; i++)
		tscr +=  scor[sol[i]]/((arr_h[i]+1)*(1-alpha[catg[sol[i]]]));
	return tscr;
}

void initial_sol (solotion &init)
{
	int slct[maxn];
	for (int i = 0 ;i<=n+1 ; i++)
		init.sol[i]=0;

    for (int i = 0 ;i<=n+1 ; i++)
		slct[i]=i;
	init.dist=0;
	init.size=0;
	int i=0;
	

	while(init.dist<=dmax)
	{
		double min = 99999;
		
			for (int j = 1 ;j<=n ; j++){
				
				if ( distnc(init.sol[i],j) < min && distnc(init.sol[i],j) !=0 && slct[j] != -1)
				{
					min = distnc(init.sol[i],j);
					//init.dist+=min;
					
				//init.dist+=distnc(j,init.size+1);
						init.sol[i+1] = j;
				}
			}
			init.dist+=distnc(init.sol[i],init.sol[i+1]);
			init.dist+=distnc(init.sol[i+1],n+1);
			if(i!=0) init.dist-=distnc(init.sol[i],n+1);
			init.size++;
			slct[init.sol[i]] = -1;
			i++;
	} 

	init.sol[init.size]=n+1;
	init.size--;
	init.dist=dist_calc(init.sol,init.size);
	h_calc(init.arrh,init.size,init.sol);
	init.tscor=scor_calc(init.sol,init.arrh,init.size);
}	

void initial_sol1 (solotion &init)
{
	int slct[maxn];
	for (int i = 0 ;i<=n+1 ; i++)
		init.sol[i]=0;

    for (int i = 0 ;i<=n+1 ; i++)
		slct[i]=i;
	for (int i = 0 ;i<=n+1 ; i++)
		init.arrh[i]=0;
	init.dist=0;
	init.size=0;
	int i=0;
	int selectedNde = -1;
	bool ndFlag = true;
	double remainTime = dmax;
	while(i<n+1 && ndFlag)
	{
		double min = 99999;
	    double max=0;
	    double ts=0;
	    double rat=0;
		ndFlag  = false;
			for (int j = 1 ;j<=n ; j++){
				if(slct[j] != -1 && (distnc(init.sol[i],j)+distnc(j,n+1))<= remainTime){
					ts =  scor[j]/(1-alpha[catg[j]]);
					rat=ts/distnc(init.sol[i],j);
					if(rat>=max){
						selectedNde = j;
						ndFlag = true;
						//init.sol[i+1] = j;
						max=rat;
					}
				}
			}
			init.sol[i+1] = selectedNde;
			init.dist+=distnc(init.sol[i],init.sol[i+1]);
			init.dist+=distnc(init.sol[i+1],n+1);
			remainTime -= distnc(init.sol[i],init.sol[i+1]);
			init.size++;
			/*if(i!=0) init.dist-=distnc(init.sol[i],n+1);
			*/
			slct[selectedNde] = -1;
			i++;
	} 

	init.sol[init.size]=n+1;
	init.dist+=distnc(init.sol[i+1],n+1);
	remainTime -= distnc(init.sol[i+1],n+1);
	init.size--;
	init.dist=dist_calc(init.sol,init.size);
	h_calc(init.arrh,init.size,init.sol);
	init.tscor=scor_calc(init.sol,init.arrh,init.size);
}	

void updt_y (solotion curr, int wht, int whr, int (&arrh)[maxn])
{
	bool _flg=true;
	int cs=-1;
	for(int i=curr.size+1; i<=curr.size+10; i++)
		arrh[i]=0;
	for(int i=0; i<=whr; i++)
	{
		if(catg[curr.sol[i]]==catg[wht])
		{
			arrh[i]=curr.arrh[i]+1;
			if(_flg){
				cs=curr.arrh[i]+1;
				_flg=false;}
		}

		if(catg[curr.sol[i]]!=catg[wht])
		{
			arrh[i]=curr.arrh[i];
		}
	}
	arrh[whr+1]=cs;
	for(int i=whr+2; i<=curr.size+1; i++)
	{
		if(catg[curr.sol[i-1]]==catg[wht])
		{
			arrh[i]=curr.arrh[i-1]+1;
		}

		if(catg[curr.sol[i-1]]!=catg[wht])
		{
			arrh[i]=curr.arrh[i-1];
		}
	}
}



//void initial_sol2 (solotion &init)
//{
//
//    int slct[maxn];
//	for (int i = 0 ;i<=n+1 ; i++)
//		init.sol[i]=0;
//
//    for (int i = 0 ;i<=n+1 ; i++)
//		slct[i]=i;
//	for (int i = 0 ;i<=n+1 ; i++)
//		init.arrh[i]=0;
//	init.dist=0;
//	init.size=0;
//	int i=0;
//	int selectedNde = -1;
//	bool ndFlag = true;
//	double remainTime = dmax;
//	while(i<n+1 && ndFlag)
//	{
//		double min = 99999;
//	    double max=-99999;
//	    double ts=0;
//	    double rat=0;
//		ndFlag  = false;
//			for (int j = 1 ;j<=n ; j++){
//				if(slct[j] != -1 && (distnc(init.sol[i],j)+distnc(j,n+1))<= remainTime){
//					updt_y(init, j, i, init.arrh);
//					ts =  scor[j]/(init.arrh[j]+1)*(1-alpha[catg[j]]);
//					rat=ts/distnc(init.sol[i],j);
//					if(rat>=max){
//						selectedNde = j;
//						ndFlag = true;
//						//init.sol[i+1] = j;
//						max=rat;
//					}
//				}
//			}
//			init.sol[i+1] = selectedNde;
//			init.dist+=distnc(init.sol[i],init.sol[i+1]);
//			init.dist+=distnc(init.sol[i+1],n+1);
//			remainTime -= distnc(init.sol[i],init.sol[i+1]);
//			init.size++;
//			/*if(i!=0) init.dist-=distnc(init.sol[i],n+1);
//			*/
//			slct[selectedNde] = -1;
//			i++;
//	} 
//
//	init.sol[init.size]=n+1;
//	init.dist+=distnc(init.sol[i+1],n+1);
//	remainTime -= distnc(init.sol[i+1],n+1);
//	init.size--;
//	init.dist=dist_calc(init.sol,init.size);
//	h_calc(init.arrh,init.size,init.sol);
//	init.tscor=scor_calc(init.sol,init.arrh,init.size);
//}

void initial_sol2_2 (solotion &init)
{
	int slct[maxn];
	for (int i = 0 ;i<=n+1 ; i++)
		init.sol[i]=0;

    for (int i = 0 ;i<=n+1 ; i++)
		slct[i]=i;
	for (int i = 0 ;i<=n+1 ; i++)
		init.arrh[i]=0;
	init.dist=0;
	init.size=0;
	int i=0;


	while(init.dist<=dmax)
	{
		double min = 99999;
	    double max=0;
	    double ts=0;
	    double rat=0;
			for (int j = 1 ;j<=n ; j++){
				
				if ( distnc(init.sol[i],j) < min && distnc(init.sol[i],j) !=0 && slct[j] != -1)
				{
					min = distnc(init.sol[i],j);
					//init.dist+=min;
					//init.arrh[j]=1;	
				//init.dist+=distnc(j,init.size+1);
					//h_calc(init.arrh,init.size+1,init.sol);
					ts =  scor[j]/(1+init.arrh[i])*(1-alpha[catg[j]]);
					rat=ts/min;
					if(rat>=max){
						init.sol[i+1] = j;
						init.arrh[i] = init.arrh[i]+1;
						max=rat;
					}
				}
			}
			init.dist+=distnc(init.sol[i],init.sol[i+1]);
			init.dist+=distnc(init.sol[i+1],n+1);
			if(i!=0) init.dist-=distnc(init.sol[i],n+1);
			init.size++;
			slct[init.sol[i]] = -1;
			i++;
			//init.sol[init.size]=n+1;
			//h_calc(init.arrh,init.size,init.sol);
	} 

	init.sol[init.size]=n+1;
	init.size--;
	init.dist=dist_calc(init.sol,init.size);
	h_calc(init.arrh,init.size,init.sol);
	init.tscor=scor_calc(init.sol,init.arrh,init.size);
}

void initial_sol_y (solotion &init)
{
	int slct[maxn];
	for (int i = 0 ;i<=n+1 ; i++)
		init.sol[i]=0;

    for (int i = 0 ;i<=n+1 ; i++)
		slct[i]=i;
	for (int i = 0 ;i<=n+1 ; i++)
		init.arrh[i]=0;
	init.dist=0;
	
	int selectedNde = -1;
	bool ndFlag = true;
	double remainTime = dmax;
	init.sol[0]=0;
	init.sol[1]=n+1;
    init.size=0;
	int i=0;
    double diff= 0;

	while(i<=n && ndFlag)
	{
		double max= -99999;
		double rat=0;	
	    ndFlag  = false;
		for (int j = 1 ;j<=n ; j++)
		{
			diff= distnc(init.sol[i],j)+distnc(j,n+1);
			init.sol[i+1] = j;
			init.sol[init.size+2]=n+1;
		    h_calc(init.arrh, init.size+1, init.sol);	
		    init.tscor=scor_calc(init.sol, init.arrh, init.size+1);
			rat=init.tscor/diff;
			if(slct[j]!=-1 && diff<=remainTime && rat>max)
			{
				selectedNde = j;
				ndFlag = true;
				max=rat;
			}
		}
		init.sol[i+1] = selectedNde;
		init.dist+=distnc(init.sol[i],init.sol[i+1]);
		init.dist+=distnc(init.sol[i+1],n+1);
		remainTime -= distnc(init.sol[i],init.sol[i+1]);
		init.size++;

		slct[selectedNde] = -1;
		i++;
	} 

	init.sol[init.size]=n+1;
	init.dist+=distnc(init.sol[i+1],n+1);
	remainTime -= distnc(init.sol[i+1],n+1);
	init.size--;
	init.dist=dist_calc(init.sol,init.size);
	h_calc(init.arrh,init.size,init.sol);
	init.tscor=scor_calc(init.sol,init.arrh,init.size);
}	

void insert_in_sol(solotion sol, solotion &inserted_sol, int wht, int whr)
{
	
	//bool _flg=true;

	for(int i=0; i<=whr; i++)
		inserted_sol.sol[i]=sol.sol[i];
	inserted_sol.sol[whr+1]=wht;
	for(int i=whr+2; i<=sol.size+2; i++)
		inserted_sol.sol[i]=sol.sol[i-1];

	inserted_sol.size=sol.size+1;
	//updt_y(inserted_sol, wht, whr, inserted_sol.arrh);
	h_calc(inserted_sol.arrh, inserted_sol.size, inserted_sol.sol);
	inserted_sol.tscor=scor_calc(inserted_sol.sol, inserted_sol.arrh, inserted_sol.size);		
	inserted_sol.dist=dist_calc(inserted_sol.sol, inserted_sol.size);
}

void output (solotion sol,bool init_or_imp)
{
	if(init_or_imp==0){
		cout<<endl<<endl;
		SetColor(15);
		cout<<"Initial Solution:  " ;SetColor(7);
		for (int i=0; i<=sol.size+1; i++){
			printf("%d ", sol.sol[i]);
		}
		cout<<endl;
		cout<<"-------------------------"<<endl;
		cout <<"D_Max: "<< dmax<<endl ;SetColor(15);
		cout <<"Initial Distance: ";SetColor(7);
	
		cout<< sol.dist <<endl;
		cout<<"-------------------------"<<endl;SetColor(15);
		cout<<"Index of y: ";SetColor(7);
		for(int i=1; i<=sol.size; i++)
			cout << sol.arrh[i] <<" "; 
		cout<<endl;
		SetColor(2);
		cout<<"Initial Score: " << sol.tscor<<endl;SetColor(7);
		cout<<"-------------------------"<<endl;
		//cout<<endl<<endl;
		cout<<"Improving... "<<endl ;
	}

	if(init_or_imp==1){
		SetColor(15);
		cout<<endl<<"Improved Solution: " ;SetColor(7);
		for (int i=0; i<=sol.size+1; i++){
				printf("%d ", sol.sol[i]);
		}
		
		cout<<endl;
		cout<<"--------------------------"<<endl;
		SetColor(15);
		cout <<"Improved Distance: ";SetColor(7);cout<< sol.dist <<endl;
		cout<<"--------------------------"<<endl;SetColor(15);
		cout<<"Index of y: ";SetColor(7);
		for(int i=1; i<=sol.size; i++)
				cout << sol.arrh[i] <<" "; 
		cout<<endl;
		SetColor(2);
		cout<<"Improved Score: " << sol.tscor<<endl;SetColor(7);
		cout<<"--------------------------"<<endl;
		cout<<endl;
		cout << "                        ---->";SetColor(15); cout<<" Run time: ";SetColor(4); cout<< (stp-strt)/double(CLOCKS_PER_SEC) <<" Sec";SetColor(7);cout<<" <----"<<endl<<endl;
	
	ofstream outfile;
	outfile.open("nnnnnnn.txt", ios::out);// ate = out bude
	//outfile.open("ok.txt");
	//outfile <<"Objective Value: " <<sol.tscor<<endl;
	outfile <<"Objective Value: " <<sol.tscor<<endl<<"Run Time: " <<(stp-strt)/double(CLOCKS_PER_SEC)<<endl<<"Solution: " ;
	//outfile <<"Run Time: " <<(stp-strt)/double(CLOCKS_PER_SEC)<<endl;
	for (int i=1; i<=sol.size; i++)
				outfile <<sol.sol[i]<<" ";
    outfile.close();

 //   ofstream outfile;
 //   outfile.open("Result.txt", ios::out);
	//for (int i=1; i<=sol.size; i++)
	//			outfile <<sol.sol[i]<<" ";
 //   outfile.close();
 //   ofstream outfile;
 //   outfile.open("Result.txt", ios::out);
	//
	//outfile <<sol.tscor<<"\t";
	//outfile <<(stp-strt)/double(CLOCKS_PER_SEC)<<"\n";
 //   outfile.close();

	} 
	//if(init_or_imp==1) system("pause");
}
