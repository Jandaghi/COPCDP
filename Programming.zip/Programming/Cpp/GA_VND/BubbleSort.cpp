﻿

#include <iostream>
#include <iterator>
#include <istream>
#include <fstream>
template <typename T> 
	
int count_elements (std::istream &is) 
{ 
   std::istream_iterator<T> start(is), end;
   return std::distance(start, end);
}

void BubbleSort()
{
	int temp_pop[maxn];
    int temp_y[maxn];

    for (int j=1 ; j<=maxp ; j++)
	{
        for (int i = 1; i <= maxp-j-1; i++) 
		{
                if (Tscore[i+1] > Tscore[i]) 
				{
                    double tmp1 = Tscore[i+1];
					Tscore[i+1] = Tscore[i];
                    Tscore[i]=tmp1;  

					double tmp2 = Tdist[i+1];
					Tdist[i+1] = Tdist[i];
                    Tdist[i]=tmp2;

					int tmp3 = Ssize[i+1];
					Ssize[i+1] = Ssize[i];
                    Ssize[i]=tmp3;

					for(int s=0; s<=n; s++)
					{
						temp_pop[s]=population[i+1][s];
						population[i+1][s] = population[i][s];
						population[i][s]=temp_pop[s];

						temp_y[s]=pop_y[i+1][s];
						pop_y[i+1][s]=pop_y[i][s];
						pop_y[i][s]=temp_y[s];
					}
                }
        }
    }
}