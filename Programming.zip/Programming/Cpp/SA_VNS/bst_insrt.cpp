
void updt_h_sol(int sol[maxn], int (&imp_sol)[maxn], int in_h[maxn], int (&out_h)[maxn], int wht, int whr, int size)
{
	
	bool _flg=true;

	if(size==0) out_h[1]=1;
	int cs=0;
	for(int i=0;i<=whr;i++)
	{
		imp_sol[i]=sol[i];
		//if(catg[sol[i]]==catg[wht]) 
		//{out_h[i]=in_h[i]+1; cs=out_h[i];}
		//if(catg[sol[i]]!=catg[wht]) 
		//	out_h[i]=in_h[i];
	}
	imp_sol[whr+1]=wht;
	//out_h[whr+1]=cs;

	for(int i=whr+2;i<=size+2;i++){
		imp_sol[i]=sol[i-1];

	}
	h_calc(out_h,size+1,imp_sol);


}

void updt_scor(int sol[maxn],int in_h[maxn], int wht, int whr, int size
	,double in_scor, double &out_scor)
{
	out_scor=in_scor;
	bool _flg=true;

	if(size==0) out_scor = scor[wht];

	for(int i=whr+1;i<=size;i++)
	{
		here:
		if(catg[sol[i]]==catg[wht])
		{
			if(_flg==true)
			{ 
				out_scor+= pow(alpha[catg[wht]],  in_h[i]-1) * scor[wht];
				out_scor-= pow(alpha[catg[sol[i]]],  in_h[i]-1) * scor[sol[i]];
			    out_scor+= pow(alpha[catg[sol[i]]],  in_h[i]) * scor[sol[i]];
				_flg=false;
				i++;
				goto here;
			}
			out_scor-= pow(alpha[catg[sol[i]]],  in_h[i]-1) * scor[sol[i]];
			out_scor+= pow(alpha[catg[sol[i]]],  in_h[i]) * scor[sol[i]];
		}
	}
}

void updt_scor1(solotion curr, int wht, int size
	,double in_scor, double &out_scor)
{
	out_scor=0;
	bool _flg=true;
	int cs=0;

	if(size==0) out_scor = scor[wht];
	for(int i=1; i<=curr.size; i++){
		if(catg[curr.sol[i]]==catg[wht]){
			curr.arrh[i]=curr.arrh[i]+1;
			
			if(_flg){
				cs=curr.arrh[i];
				_flg=false;
			}
		}else{
			curr.arrh[i]=curr.arrh[i];
		}
	}
    curr.arrh[curr.size+1]=cs;
	curr.arrh[curr.size+2]=0;
	//updt_y(curr, wht, whr, curr.arrh);	
	
	
	for(int i=1; i<=curr.size; i++)
		//out_scor +=  scor[curr.sol[i]]/(curr.arrh[i]+1)*(1-alpha[catg[i]]);
	out_scor += scor[curr.sol[i]]/((curr.arrh[i]+1)*(1-alpha[catg[curr.sol[i]]]));
}

void bst_insrt0 (solotion curr,solotion &imp, bool &imp_flg)
{
	double max=-9999;
	double min=9999;
	double diff=0;
	int slct[maxn];
	double dist=0;
	double Ratio=0;
	int wht=0;
	int whr=0;
	imp_flg=false;

	double rmain=dmax-curr.dist;

	for(int i=0; i<=n; i++)
		slct[i]=0;
	for(int i=0; i<=curr.size; i++)
		slct[curr.sol[i]]=-1;
	
	for(int i=1; i<=n; i++)                            //what
		if(slct[i]==0)
		{
			for(int j=0; j<=curr.size; j++)            //where
			{                                             
				if(slct[j]==-1)
				{
					diff = distnc(curr.sol[j],i) + distnc(i,curr.sol[j+1]) - distnc(curr.sol[j],curr.sol[j+1]);
					if(diff<=rmain)
					{
						 updt_scor(curr.sol, curr.arrh, i, j, curr.size, curr.tscor, imp.tscor);
						 //cout<<endl<<scor_calc(curr.sol,curr.arrh,curr.size)<<endl;
						 
						 Ratio=imp.tscor/diff;
						 
						 if(Ratio>max)
						 {
							 wht=i; whr=j; max=Ratio; min=diff;
							 imp_flg=true;
						 }
				    }
				}			
			}
		}
		if(imp_flg==true)
		{
			updt_h_sol(curr.sol, imp.sol, curr.arrh, imp.arrh, wht, whr, curr.size);
			imp.dist=curr.dist+min;
			imp.tscor=max*min;
			imp.size=curr.size+1;
		}
}
	
void bst_insrt00 (solotion sol2, solotion &sol3, bool &insrt_flg){
	double max=-9999;
	double min=99999;
	double diff=0;
	bool slct[maxn];
	//double dist=0;
	double Ratio=0;
	int selectedNode = -1;
	int slectedPosition = -1;
	int wht=-1;
	int whr=-1;
	insrt_flg=false;

	double rmain=dmax-sol2.dist;
	//if(rmain<=0)  //goto endd;

	for(int i=0; i<=n; i++)
		slct[i]=0;
	for(int i=0; i<=sol2.size; i++)
		slct[sol2.sol[i]]=1;
	
	for(int i=1; i<=n; i++) //what
	{
		if(slct[i]==false)
		{
			min = 99999;
			for(int j=0; j<=sol2.size; j++)            //where
			{                                    
					diff = distnc(sol2.sol[j],i) + distnc(i,sol2.sol[j+1]) - distnc(sol2.sol[j],sol2.sol[j+1]);
					if(diff<=rmain && diff<min)
					{
						min=diff;
						whr=j;
						insrt_flg=true;
					}
			}
			if(insrt_flg==true ){
				updt_scor1(sol2, i, sol2.size, sol2.tscor, sol3.tscor);
				Ratio=sol3.tscor/min;
				if(Ratio>=max){
					selectedNode = i;
					slectedPosition = whr;
					max=Ratio;
					//changeScore = imp.tscor;
				}
			}
	  }
	}
		if(max > 0 && insrt_flg==true)
		{
			updt_h_sol(sol2.sol, sol3.sol, sol2.arrh, sol3.arrh, selectedNode, slectedPosition, sol2.size);
			sol3.size=sol2.size+1;
			//h_calc(imp.arrh,imp.size,imp.sol);
			sol3.dist=dist_calc(sol3.sol,sol3.size);
			sol3.tscor=scor_calc(sol3.sol,sol3.arrh,sol3.size);
		}

if(insrt_flg==false) cpy_sol(sol2,sol3);
}

void best_insert_FirstImp (solotion curr,solotion &imp, bool &imp_flg){
	double max=-.01;
	double min=99999;
	double diff=0;
	bool slct[maxn];
	//double dist=0;
	double Ratio=0;
	int wht=0;
	int whr=0;
	imp_flg=false;

	double rmain=dmax-curr.dist;
	//if(rmain<=0)  //goto endd;

	for(int i=0; i<=n; i++)
		slct[i]=0;
	for(int i=0; i<=curr.size; i++)
		slct[curr.sol[i]]=1;
	
	for(int i=1; i<=n; i++) //what
	{
		if(slct[i]==false)
		{
			updt_scor1(curr, i, curr.size, curr.tscor, imp.tscor);
			for(int j=0; j<=curr.size; j++)            //where
			{        
				double dif_score=curr.tscor-imp.tscor;                            
					diff = distnc(curr.sol[j],i) + distnc(i,curr.sol[j+1]) - distnc(curr.sol[j],curr.sol[j+1]);
					if(diff<=rmain && diff<min && dif_score>0 && Ratio>=max )
					{
						min=diff;
						whr=j;
					    imp_flg=true;
						wht=i;
						Ratio=imp.tscor/min;
				    }
			}	
		}
	  }
	
		if(imp_flg==true)
		{
			updt_h_sol(curr.sol, imp.sol, curr.arrh, imp.arrh, wht, whr, curr.size);
			imp.size=curr.size+1;
			h_calc(imp.arrh,imp.size,imp.sol);
			imp.dist=dist_calc(imp.sol,imp.size);
			imp.tscor=scor_calc(imp.sol,imp.arrh,imp.size);
		}
		
}

void updt_scor_insr (solotion curr, int wht, int whr , double &out_scor)
{
	solotion cur2;
	insert_in_sol(curr, cur2, wht, whr);
	out_scor=cur2.tscor;
}

void best_insert_BestImp (solotion sol, solotion &imp, bool &imp_flg)
{
	double max=-9999;
	double min=999999;
	double diff=0;
	bool slct[maxn];
	double Ratio=0;
	int wht=-1;
	int whr=-1;
	int kk=-1;
	int temp_cust;
	int temp_pos;
	double cheapest;
	double dlta_scor;

	imp_flg=false;
	bool feas=false;

	double available_dist=dmax-sol.dist;
	double changed_scor=0;

	for(int i=0; i<=n; i++)
		slct[i]=0;
	for(int i=0; i<=sol.size; i++)
		slct[sol.sol[i]]=1;

	h_calc(sol.arrh, sol.size, sol.sol);

	max = -9999 ;
	for (int k = 1; k<=n; k++)
	{
		//max = -9999 ;
		if (slct[k]==0) 
		{
			min=9999999;
			feas =false;
			for (int j=0; j<=sol.size ;j++)
			{
				diff=distnc(sol.sol[j], k)+distnc(k, sol.sol[j+1])-distnc(sol.sol[j], sol.sol[j+1]);
				if (diff <= min && diff <= available_dist && sol.sol[j]!=k)
				{
					min=diff;
					kk=j+1;
					feas=true;
				}
			}
			if(feas ){
				updt_scor_insr(sol, k, kk-1, changed_scor);
				dlta_scor=changed_scor-sol.tscor;
			}
															
			if (feas && dlta_scor>=0 && dlta_scor/min > max)
			{
					temp_cust=k;
					temp_pos=kk;
					cheapest=min;
					max=dlta_scor/min;
					imp_flg=true;
			}
		}
	}
			
	if (imp_flg/*max>0.00001*/)
	{
		insert_in_sol(sol, imp, temp_cust, temp_pos-1);
		imp_flg=true;
	}else{
		imp_flg=false;
	}
}

