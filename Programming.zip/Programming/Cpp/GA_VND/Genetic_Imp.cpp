#include "initial_NN.cpp"
#include "bst_insrt.cpp"
#include "two_opt.cpp"
#include "swap.cpp"
#include "LS.cpp"
#include "BubbleSort.cpp"

void cpy_sol_gen(solotion in_sol, int i) 
{
	for(int j=0; j<=in_sol.size+1 ; j++)
	{
		population[i][j]= in_sol.sol[j];
		pop_y[i][j]= in_sol.arrh[j];
	}
	Ssize[i]=in_sol.size;
	Tdist[i]=in_sol.dist;
	Tscore[i]=in_sol.tscor;
}

void cpy_gen_sol (solotion &in_sol, int i) 
{
	in_sol.size=Ssize[i];
	for(int j=0; j<=in_sol.size+1 ; j++)
	{
		in_sol.sol[j]=population[i][j]; 
		in_sol.arrh[j]=pop_y[i][j];
	}
	in_sol.dist=Tdist[i];
	in_sol.tscor=Tscore[i];
	
}

void init_gen_rand() 
{

	solotion sol1;
	sol1.sol[0]=0;
	double tmp=0;
	initial_rand(sol1);
	cpy_sol_gen(sol1, 1);

	for(int i=2; i<=maxp-1; i++)
	{	
		
		tmp=sol1.tscor;
		ag:
		initial_rand(sol1);
		if((sol1.tscor-tmp)!=0)
			cpy_sol_gen(sol1, i);
		else
			goto ag;
	}
}



//void init_gen_best() {
//
//	double beta_init=0.3;
//	bool flg=false;
//
//	solotion cur1;
//	solotion cur2;
//	cur1.tscor=-1;
//	cur2.tscor=-1;
//	solotion init1;
//	solotion init2;
//	solotion init3;
//	solotion init4;
//
//	initial_sol1(init1);
//	cpy_sol_gen(init1, 1);
//	
//	initial_sol_y(init2);
//	cpy_sol_gen(init2, 2);
//
//	for(int i=3; i<=maxp-2; i++)
//	{
//		a1:
//		shaking(init1, init3, beta_init);
//		if(init3.tscor==cur1.tscor)	goto a1;
//	
//		cpy_sol(init3, cur1);
//		
//		//best_insert_BestImp(init3, init3, flg);
//	    cpy_sol_gen(init3, i);
//		i++;
//
//		a2:
//		shaking(init2, init4, beta_init);
//		if(init4.tscor==cur2.tscor)	goto a2;
//		cpy_sol(init4, cur2);
//		//best_insert_FirstImp(init4, init4, flg);
//		cpy_sol_gen(init4, i);
//
//	}
//
//}


void repeat_chk (int (&crossed)[maxn], int &cros_size)
{
	for (int i=1; i<=cros_size-1; i++)
	{
		for (int j=i+1; j<=cros_size; j++)
		{
			if(crossed[i]==crossed[j])
			{
				for (j ; j<=cros_size+1; j++)
					crossed[j]=crossed[j+1];
				cros_size--;
			}
		}
	}
	//again:
	//for (int i=1; i<=cros_size-1; i++)
	//{
	//	for (int j=i+1; j<=cros_size; j++)
	//	{
	//		if(crossed[i]==crossed[j])
	//		{
	//			if(crossed[j]==n)
	//			{
	//				crossed[j]--;
	//				goto again;
	//			}
	//			crossed[j]++;
	//			goto again;
	//		}
	//	}
	//}
}

void feas_chk (int (&crossed)[maxn], int &cros_size)
{
	double dis=0;
	dis=dist_calc(crossed, cros_size);
	
	if(dis>dmax)
		while(dis>dmax)
		{
			dis-=distnc(crossed[cros_size], n+1);
			dis-=distnc(crossed[cros_size-1], crossed[cros_size]);
			dis+=distnc(crossed[cros_size-1], n+1);
			
			crossed[cros_size]=crossed[cros_size+1];
			cros_size--;
		}
		
}

void repair (int (&crossed)[maxn], int &cros_size)
{
	repeat_chk(crossed, cros_size);
	feas_chk(crossed, cros_size);
}

void cross_over(int num1, int num2)
{
	int cros_size1=0;
	int cros_size2=0;
	int crossed1[maxn];
	int crossed2[maxn];
	crossed1[0]=0;
	crossed2[0]=0;
	int size1=Ssize[num1]/2;
	int size2=Ssize[num2]/2;
	int c=1;
//..............................................................................................
	for(int i=1; i<=size1; i++)
		crossed1[i]=population[num1][i];

	for(int i=size1+1; i<=size1+Ssize[num2]+1; i++)
	{
		crossed1[i]=population[num2][size2+c];
		c++;
	}

	cros_size1=size1+Ssize[num2]-size2;
	
	repair (crossed1, cros_size1);


/// next chrom crossing////////////////////////////////////////
	
	for(int i=1; i<=size2; i++)
		crossed2[i]=population[num2][i];
	c=1;
	for(int i=size2+1; i<=size2+Ssize[num1]+1; i++)
	{
		crossed2[i]=population[num1][size1+c];
		c++;
	}

	cros_size2=size2+Ssize[num1]-size1;
	
	repair (crossed2, cros_size2);
//................................................................................................

	for(int i=1; i<=cros_size1+1; i++)
		population[num1][i]=crossed1[i];
	
	Ssize[num1]=cros_size1;
	Tdist[num1]=dist_calc(crossed1, cros_size1);
	h_calc(pop_y[num1], Ssize[num1], crossed1);
	Tscore[num1]=scor_calc(crossed1, pop_y[num1], Ssize[num1]);

	for(int i=1; i<=cros_size2+1; i++)
		population[num2][i]=crossed2[i];
	
	Ssize[num2]=cros_size2;
	Tdist[num2]=dist_calc(crossed2, cros_size2);
	h_calc(pop_y[num2], Ssize[num2], crossed2);
	Tscore[num2]=scor_calc(crossed2, pop_y[num2], Ssize[num2]);
}

void mutation(int num0)
{
	int dlt=0;
	int rnd_num;
	dlt=beta*Ssize[num0];
	int slct_rnd[maxn];

	for(int b=0; b<=n+1; b++)
		slct_rnd[b]=0;

	for(int i=1; i<=dlt; i++)
	{
		
		rnd_num=1 + int((Ssize[num0])*rand()/(RAND_MAX + 1.0));
				
		slct_rnd[rnd_num]=1;

		Tdist[num0]-=distnc(population[num0][rnd_num-1], population[num0][rnd_num]);
		Tdist[num0]-=distnc(population[num0][rnd_num], population[num0][rnd_num+1]);
		Tdist[num0]+=distnc(population[num0][rnd_num-1], population[num0][rnd_num+1]);

		for(int j=1; j<=Ssize[num0]; j++)
		{			
			if(catg[population[num0][j]]==catg[population[num0][rnd_num]])
				pop_y[num0][j]=pop_y[num0][j]-1;
		}
		for(int j=rnd_num; j<=Ssize[num0]; j++)
		{
			population[num0][j]=population[num0][j+1];
			pop_y[num0][j]=pop_y[num0][j+1];
		}

		Ssize[num0]--;

	}
	//double di=dist_calc(population[num0], Ssize[num0]);
	Tscore[num0] = scor_calc(population[num0], pop_y[num0], Ssize[num0]);
}

void next_gen()
{
	int rnd_num;
	int c1=1;
	int c2=1;
	int num0=1;
	int num1=1;
	int num2=1;
	
	for(int i=0; i<maxp; i++)
		slctd_gen[i]=0;

	//for(int i=maxp; i<maxp-wrst_gen; i--)
	//	slctd_gen[i]=1;

	while (c1<=mut_gen)
	{
		again0:
		rnd_num=1 + int((maxp-1)*rand()/(RAND_MAX + 1.0));
		if(slctd_gen[rnd_num]==0)
		{
			num0=rnd_num;
			slctd_gen[num0]=1;
		}
		else
			goto again0;
		mutation(num0);
		c1++;
	}

	while (c2<=crs_gen/2)
	{
		again1:
		rnd_num=1 + int((maxp-1)*rand()/(RAND_MAX + 1.0));
		if(slctd_gen[rnd_num]==0)
		{
			num1=rnd_num;
			slctd_gen[num1]=1;
		}
		else
			goto again1;

		again2:
		rnd_num=mut_gen+1 + int((crs_gen+mut_gen)*rand()/(RAND_MAX + 1.0));
		if(slctd_gen[rnd_num]==0)
		{
			num2=rnd_num;
			slctd_gen[num2]=1;
		}
		else
			goto again2;
		
		cross_over(num1, num2);	
		
		c2++;
	}
}

void next_gen_LS()
{
	solotion sol;
	for(int i=1; i<=maxp-1; i++)
	{
		cpy_gen_sol(sol, i);
		local_search(sol, sol);
		cpy_sol_gen(sol, i);
	}
}

void main()
{
	//bool mode=0;
	//cout<<"Select mode: 0 Normal    1 Taguchi (0 or 1)?  ";
	//cin>> mode;
	//if(!mode)
	//	goto normal;
	//else
	//	goto Taguchi;

	//if(mode)
	//{
	//	Taguchi:
	//	cout<<"Give SA parameter set name? (1 to 16) ";
	//	cin>>give_par_set_name;
	//	input_Taguchi(give_par_set_name);
	//	SA_set_par(give_par_set_name);
	//	double tagu_scor[6][16];
	//	double tagu_time[6][16];
	//	for(int i=0; i<=16;i++)
	//		for(int j=0; j<=5; j++)
	//			tagu_scor[j][i]=0;
	//	for(int i=0; i<=16;i++)
	//		for(int j=0; j<=5; j++)
	//			tagu_time[j][i]=0;
	//	int ins=1;
	//	for(int i=1; i<=15; ins=foo(i))
	//	{
	//		input_Taguchi(ins);

	//		for(int j=1; j<=5; j++)
	//		{
	//			solotion sol;
	//			solotion sol1;
	//			srand(time(0));

	//			//input ();
	//			init_gen_rand();
	//			BubbleSort();
	//			cpy_gen_sol(sol, 1);
	//			//output(sol, 0);
	//
	//			strt=clock();

	//			int iter_gen=1;
	//			int itr=1;
	//			while (iter_gen <= iter_max && itr<=iter_max)
	//			{
	//				next_gen();
	//				BubbleSort();
	//				cpy_gen_sol(sol, 1);
	//				next_gen_LS();
	//				BubbleSort();
	//				cpy_gen_sol(sol1, 1);
	//				if(sol.tscor-sol1.tscor==0)
	//					iter_gen++;	
	//				itr++;
	//			}

	//			stp=clock();	

	//			cpy_gen_sol(sol1, 1);
	//		
	//			tagu_scor[j][i]=sol1.tscor;
	//			tagu_time[j][i]=(stp-strt)/double(CLOCKS_PER_SEC) ;				
	//		}
	//		cout<< "Instance("<<i<<") done!"<<endl;
	//		cout<< 6.6666666666666666666666666666667*i<<" % of total proccess is done"<<endl;
	//		i++;
	//	}
	//	ofstream outfile;
	//	outfile.open("Result_Tscore.txt", ios::out);
	//
	//	ins=1;
	//	for(int i=1; i<=15; ins=foo(i))
	//	{
	//		for(int j=1; j<=5; j++)
	//			outfile <<tagu_scor[j][i]<<"\t";
	//		outfile<<"\n";
	//		i++;
	//	}
	//	outfile.close();
	//	ofstream outfile1;
	//	outfile1.open("Result_Time.txt", ios::out);
	//
	//	ins=1;
	//	for(int i=1; i<=15; ins=foo(i))
	//	{
	//		for(int j=1; j<=5; j++)
	//			outfile1 <<tagu_time[j][i]<<"\t";
	//		outfile1<<"\n";
	//		i++;
	//	}
	//	outfile1.close();

	//}
	//ofstream outfile;
	bool mode=0;
	if(!mode)
	{
		normal:
		NextInstance:
		solotion sol;
		solotion sol1;
		//cout<<time(0);
		srand(time(0));
		//srand(1546428255);

		input ();

		strt=clock();

		init_gen_rand();
		BubbleSort();
		cpy_gen_sol(sol, 1);
		output(sol, 0);
	
		

		int iter_gen=1;
		int itr=1;
		while (iter_gen <= iter_max /*&& itr<=iter_max*/)
		{
			next_gen();
			BubbleSort();
			cpy_gen_sol(sol, 1);
			next_gen_LS();
			BubbleSort();
			cpy_gen_sol(sol1, 1);
			if(sol.tscor-sol1.tscor==0)
				iter_gen++;	
			itr++;
		}

		stp=clock();	

		cpy_gen_sol(sol1, 1);
		output(sol1, 1);

		goto NextInstance;
	}	
}
