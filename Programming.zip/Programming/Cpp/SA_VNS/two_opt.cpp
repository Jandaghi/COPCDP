

void two_opt_FirstImprove (solotion &sol) 
{
	int arr[maxn]; for(int i=0; i<=n+1; i++) arr[i]=0;

    for (int i=0; i<sol.size; i++)
	{
	  for (int k=i+2; k<=sol.size; k++)
	  {
		 if ( (distnc(sol.sol[i],sol.sol[k]) + distnc(sol.sol[i+1],sol.sol[k+1])) 
			 < (distnc(sol.sol[i],sol.sol[i+1]) + distnc(sol.sol[k],sol.sol[k+1])))
		 {
			for(int ii=i+1;ii<=k;ii++)
				arr[ii]=sol.sol[ii];
		    sol.sol[i+1]=arr[k];
			sol.sol[k]=arr[i+1];

			int p=0;
			for (int t=i+2; t<=k-1; ++t){
				sol.sol[t]=arr[k-1-p];
				p++;
			}
		  } 
	   }
    }
	sol.dist=dist_calc(sol.sol, sol.size);
	h_calc(sol.arrh, sol.size, sol.sol);
	sol.tscor=scor_calc(sol.sol, sol.arrh, sol.size);
}


void two_opt_BestImprove (solotion &sol, bool &opt_flg) 
{
	double max=-99999;
	double diff=0;
	int selected_i=-1;
	int selected_k=-1;
	int arr[maxn]; 
	opt_flg=false;
	for(int i=0; i<=n+1; i++) 
		arr[i]=0;

    for (int i=0; i<=sol.size; i++)
	{
	 
	  for (int k=i+2; k<=sol.size; k++)
	  {
		diff =distnc(sol.sol[i],sol.sol[i+1]) + distnc(sol.sol[k],sol.sol[k+1])
			- distnc(sol.sol[i],sol.sol[k]) - distnc(sol.sol[i+1],sol.sol[k+1]); 
			  
		 if ( diff > max && diff>0.00001)
		 {
			 selected_k = k;
			 selected_i = i;
			 max = diff;
			 opt_flg=true;
		  } 
	   }
    }
	if(opt_flg)
	{
		for(int ii=selected_i+1;ii<=selected_k;ii++)
			arr[ii]=sol.sol[ii];
		sol.sol[selected_i+1]=arr[selected_k];
		sol.sol[selected_k]=arr[selected_i+1];

		int p=0;
		for (int t=selected_i+2; t<=selected_k-1; ++t){
			sol.sol[t]=arr[selected_k-1-p];
			p++;
		}
		sol.dist=dist_calc(sol.sol, sol.size);
		h_calc(sol.arrh, sol.size, sol.sol);
		sol.tscor=scor_calc(sol.sol, sol.arrh, sol.size);
	}
}
